# Snowflake Insights Dashboard

This is a simple Flask-based dashboard project that simulates data analysis using a CSV file (representing Snowflake data).

## Features
- View total users, orders, and revenue.
- Simple HTML dashboard.

## How to Run

1. Install dependencies:
   ```
   pip install flask pandas
   ```

2. Run the app:
   ```
   python app.py
   ```

3. Open your browser and go to `http://127.0.0.1:5000/`

Enjoy!
