from flask import Flask, render_template
import pandas as pd

app = Flask(__name__)

@app.route("/")
def dashboard():
    df = pd.read_csv("data.csv")
    total_users = df["users"].sum()
    total_orders = df["orders"].sum()
    total_revenue = df["revenue"].sum()
    return render_template("dashboard.html",
                           total_users=total_users,
                           total_orders=total_orders,
                           total_revenue=total_revenue)

if __name__ == "__main__":
    app.run(debug=True)
